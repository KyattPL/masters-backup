# mgr

## 01 Trope Twist - Trope-based Narrative Structure Generation

- Generacja i ewaluacja narracyjnych struktur całych gier
- Jest bardzo ogólna
- Fajne wyekstrachowanie typowych narrative tropes:
  - HERO - A protagonist character.
  - 5MA - Group composed by up-to-five archetypical characters.
  - NEO - Specific hero chosen as the one.
  - SH - Specific hero with unique abilities.
  - CONF - Non-specific problem to overcome between characters.
  - ENEMY - A nemesis to the hero.
  - EMP - Collective enemy with the ambition of conquering the world.
  - itd, wszystko zerżnięte z https://tvtropes.org/pmwiki/pmwiki.php/Main/Tropes
- Można myśleć o dołączeniu tego rozwiązania jako preconditions przy tworzeniu danych fragmentów questów
- Praca wykorzystuje **narrative graphs**
- Common narrative structures used in many domains are Aristotle’s drama structure, which subdivides a story into
  - exposition, 
  - climax, 
  - resolution

## 02 Story Designer: Towards a Mixed-Initiative Tool to Create Narrative Structures

- Rozszerzenie 01 Trope Twista ojako tool do ewaluacji i podpowiadania przy tworzeniu narracyjnych grafów.
- Wprowadzono dodatkowe wymiary CONFLICT, DIVERSITY, PLOT_POINTS_ PLOT_DEVICES, PLOT_TWISTS


## 03 Application of Graphs for Story Generation in Video Games

- Patrzenie na plot jako game eventy zmieniające świat gry (nazywane w pracy 'produkcjami')
- Produkcja jest transformacją grafu, ma dwie strony: lewą-przed i prawą-po
- Dana produkcja jest możliwa do wykonania, jeżeli w grafie reprezentującym świat znajdziemy podgraf reprezentujący lewą stronę danej produkcji
- Akcja gry to kolejne produkcje
- Można to wykorzystać do generowania questów, poprzez definicję odpowiednich produkcji. Questem byłaby sekwencja produkcji.
- **Dodano możliwość definiowania szczegółowych produkcji, które byłyby prioretyzowane**
  - np. zamiast 'Picking up an item' można zdefiniować 'Getting the dragon tooth'

## 04 Let CONAN tell you a story: Procedural quest generation

- Listuje inne systemy do generacji, które można podzielić na ze względu na czas tworzenia questa:
  - dynamiczne dogenerowujące części questa w trakcie jego trwania
  - w całości przed przystąpieniem do questa
- Wskazuje planowanie questów jako atrakcyjne w porównaniu do wykorzystania story grammars or scripting z powodu na możliwości przeszukiwania większej przestrzeni możliwych historii
- Planowanie wymaga
  - Zdefiniowania wszystkich możliwych do zaistnienia zdarzeń
  - Początkowego stanu świata
  - Celu (ostatecznego stanu świata)
- Problemem naiwnego planowania jest fakt, że nie dba ono o wiarygodność postaci. Jako przykład podano zamkniętą księżniczkę w zamku. Tradycyjne systemy planowania mogą wygenerować jako historię, że księżniczka sama się zamknęła.
- Istnieją systemy 'deliberative narrative systems', które generują historie zaspokajające pewne constrainty nadawane przez wykorzystujących ich ludzi.
- Multi-agent simulation and distributed planning approaches create plans for each agent, depending on the current context and world state, solving the problem of making intentional agents. 
- Podział questów na:
  - place oriented - pójść z A do B i po drodze przygody
  - time oriented - np. przetrwać przez n minut
  - objective oriented - te ciekawe.
- Stworzyli w ramach pracy system do generowania questów na podstawie głównej pracy
  - Definiując świat nadają wagi dla danych postaci dla poszczególnych akcji (aby chłop nie zlecał zabójstw itd.)
  - Tworzą questy za pomocą planowania i następnie próbują przyporządkować im motywację (tak jakby potwierdzając, czy quest ma sens) - osobiście skłaniam się do robienia na odwrót
  - Przeprowadzają testy na małym, średnim i dużym predefiniowanym świecie
  - podają przykłady questów, które otrzymali
- WARTO ZWRÓCIĆ UWAGĘ, ŻE GŁÓWNA PRACA UNIKA PROBLEMU PLANOWANIA
- TODO: Zerknąć na system wykorzystujący strukturalne regóły zamiast planowania https://www.academia.edu/2600453/Towards_procedural_quest_generation_A_structural_analysis_of_RPG_quests

## 13 Multi-Paths Generation for Structural Rule Quests

- Wprowadzenie do głównej pracy condition based approach aby generować poddrzewa czynności skutkujące dokładnie takim samym stanem gry
-przeczytać jeszcze raz,