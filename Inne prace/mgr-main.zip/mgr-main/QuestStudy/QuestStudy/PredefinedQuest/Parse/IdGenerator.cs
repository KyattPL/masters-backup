﻿namespace SkaldQuestStudy.PredefinedQuest.Parse;

public class IdGenerator : IUniqueValueGenerator<int>
{
    private int _id = 0;

    public int GetValue()
    {
        return ++_id;
    }
}