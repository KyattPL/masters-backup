﻿using System.Text;

namespace SkaldQuestStudy.PredefinedQuest.Parse;

public static class GraphVisualizer
{
    public static string Visualize(Action root)
    {
        var builder = new StringBuilder();
        builder.Append("digraph G {\r\nsplines=\"FALSE\";\r\n");

        builder.AppendLine("/* Entities */");

        AddActionDefinition(root, builder);

        builder.Append("\r\n/* Relationships */\r\n");
        AddRelationsToChildren(root, builder);

        builder.AppendLine("}");
        return builder.ToString();
    }

    private static void AddActionDefinition(Action action, StringBuilder builder)
    {
        builder.AppendLine($"{action.Id} [label=\"{action.Name.Replace("\n", "\\n")}\"{GetStyle(action.Style)}]");
        foreach(var child in action.Children) AddActionDefinition(child, builder);
    }
    
    private static void AddRelationsToChildren(Action action, StringBuilder builder)
    {
        var childrenIds = action.Children.Select(child => child.Id);
        foreach(var id in childrenIds) builder.AppendLine($"{action.Id} -> {id}");
        foreach(var child in action.Children) AddRelationsToChildren(child, builder);
    }

    private static string GetStyle(Style style)
    {
        return style switch
        {
            Style.Default => "",
            Style.Dashed => ", style=dashed",
            Style.Atom => ", style=filled, fillcolor=lightblue",
            Style.Hex => ", shape=hexagon",
            Style.Rectangle => ", shape=rectangle",
            Style.Orange => ", style=filled, fillcolor=orange",
            Style.OrangeRect => ", style=filled, fillcolor=orange, shape=rectangle",
            Style.OrangeHex => ", style=filled, fillcolor=orange, shape=hexagon",
            Style.Green => ", style=filled, fillcolor=lightgreen",
            Style.GreenRect => ", style=filled, fillcolor=lightgreen, shape=rectangle",
            Style.GreenHex => ", style=filled, fillcolor=lightgreen, shape=hexagon",
            _ => ""
        };
    }
    
    
}