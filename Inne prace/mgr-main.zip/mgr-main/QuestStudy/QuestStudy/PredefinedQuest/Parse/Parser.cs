﻿using System.Text.Json;
using System.Text.Json.Serialization;

namespace SkaldQuestStudy.PredefinedQuest.Parse;

public static class Parser
{
    public static Action Parse(string jsonQuest)
    {
        var quest = JsonSerializer.Deserialize<JsonAction>(jsonQuest);
        if (quest is null)
        {
            throw new ArgumentException($"Cannot parse:\n{jsonQuest}");
        }
        
        return ConvertJsonToAction(quest);
    }

    private static Action ConvertJsonToAction(JsonAction rootAction)
    {
        IUniqueValueGenerator<int> ids = new IdGenerator();

        if (rootAction.Name.Contains("\n"))
        {
            int doopa = 0;
        }

        return new Action()
        {
            Id = ids.GetValue(),
            Name = rootAction.Name,
            Style = rootAction.Style ?? Style.Default,
            Children = GetJsonActionChildren(rootAction.SubActions, ids)
        };
    }

    private static List<Action> GetJsonActionChildren(List<JsonAction>? children, IUniqueValueGenerator<int> ids)
    {
        return children switch
        {
            null => new List<Action>(),
            _ => children.ConvertAll(action => new Action(){Id = ids.GetValue(), Style = action.Style ?? Style.Default, Name = action.Name, Children = GetJsonActionChildren(action.SubActions, ids)})
        };
    }
    
    private class JsonAction
    {
        public string Name { get; set; }
        [JsonConverter(typeof(JsonStringEnumConverter))]
        public Style? Style { get; set; }
        public List<JsonAction>? SubActions { get; set; }
    }
}

public struct Action
{
    public int Id { get; init; }
    public string Name { get; init; }
    public Style Style { get; init; }
    public List<Action> Children { get; init; }
}

public enum Style
{
    Default,
    Dashed,
    Atom,
    Hex,
    Rectangle,
    Orange,
    Green,
    GreenRect,
    GreenHex,
    OrangeRect,
    OrangeHex
}