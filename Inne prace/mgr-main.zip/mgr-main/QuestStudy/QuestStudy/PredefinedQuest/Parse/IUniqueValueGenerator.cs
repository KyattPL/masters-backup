﻿namespace SkaldQuestStudy.PredefinedQuest.Parse;

public interface IUniqueValueGenerator<out T>
{
    T GetValue();
}