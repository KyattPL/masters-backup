﻿// See https://aka.ms/new-console-template for more information

using SkaldQuestStudy.PredefinedQuest.Parse;

const string graphsSubdirectory = "Graphs";
const string treesSubdirectory = "Trees";

if (args.Length != 1)
{
    Console.WriteLine("Please provide a path to your QuestData directory");
    return 404;
}

var directory = $"{args[0]}";
var definitionsDir = $"{args[0]}\\Definitions";

if (!Directory.Exists(directory))
{
    throw new DirectoryNotFoundException($"{definitionsDir} does not exist");
}

var paths = CreateDirectoryStructure();

var allFiles = Directory.GetFiles(definitionsDir, "*.json").ToList().ConvertAll(jsonPath => (Path.GetFileNameWithoutExtension(jsonPath), File.ReadAllText(jsonPath)));

foreach (var (filename, text) in allFiles)
{
    File.WriteAllText($"{paths.graphs}\\{filename}.dot", GraphVisualizer.Visualize(Parser.Parse(text)));
}

return 0;

(string graphs, string trees) CreateDirectoryStructure()
{
    var graphsPath = $"{directory}\\{graphsSubdirectory}";
    if (!Directory.Exists(graphsPath))
    {
        Directory.CreateDirectory(graphsPath);
    }

    var treesPath = $"{directory}\\{treesSubdirectory}";
    if (!Directory.Exists(graphsPath))
    {
        Directory.CreateDirectory(treesPath);
    }

    return (graphsPath, treesPath);
}