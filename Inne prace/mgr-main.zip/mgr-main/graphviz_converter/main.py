import sys
from os import listdir, system
from os.path import isfile, join, isdir, splitext


def get_all_dot_files(directory):
    return [(splitext(f)[0], f'{directory}\\{f}') for f in listdir(directory) if isfile(join(directory, f)) and splitext(f)[1] == '.dot']


def run(dot_files_dir, output_dir, extension):
    if not isdir(dot_files_dir):
        print('provide path to a directory containing dot files')
    if not isdir(output_dir):
        print('provide path to an existing output directory')

    dot_files = get_all_dot_files(dot_files_dir)
    for (filename, path) in dot_files:
        output_path = f'{output_dir}\\{filename}.{extension}'
        print(f"creating {filename}.png in {output_path}")
        system(f'dot.exe -T{extension} {path} > {output_path}')


if __name__ == '__main__':
    run(sys.argv[1], sys.argv[2], sys.argv[3])

